﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;

namespace BloodBankManagement
{
    public partial class DonorForm : UserControl
    {
        SqlDataReader rdr = null;
        DataTable dtable = new DataTable();
        SqlConnection con = null;
        SqlCommand cmd = null;
        DataTable dt = new DataTable();
        ConnectionString cs = new ConnectionString();

        private static DonorForm _instance;

        public static DonorForm Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new DonorForm();
                return _instance;
            }
        }

        public DonorForm()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Hide();
            rest();
            btnUpdate.Visible = false;
            btnDelete.Visible = false;
            btnSave.Visible = true;
        }

        private void AutoIdGeneration()
        {
            int Num = 0;
            con = new SqlConnection(cs.DBConn);
            con.Open();
            string sql = "SELECT Max(Id+1) FROM DonorTable";
            cmd = new SqlCommand(sql);
            cmd.Connection = con;
            if (Convert.IsDBNull(cmd.ExecuteScalar()))
            {
                Num = 1;
                lblDonor.Text = Convert.ToString(Num);
                txtDonorNo.Text = Convert.ToString("D-" + Num);
            }
            else
            {
                Num = System.Convert.ToInt32((cmd.ExecuteScalar()));
                lblDonor.Text = Convert.ToString(Num);
                txtDonorNo.Text = Convert.ToString("D-" + Num);
            }
            cmd.Dispose();
            con.Close();
            con.Dispose();
        }

        private void rest()
        {
            txtName.Text = "";
            txtAddress.Text = "";
            txtMobileNumber.Text = "";
            txtAge.Text = "";
            cmbGender.Text = "";
            cmbBloodGroup.Text = "";
            cmbEyeColor.Text = "";
            txtCNICNo.Text = "";
            txtHeight.Text = "";
        }

        private void DonorForm_Load(object sender, EventArgs e)
        {
            AutoIdGeneration();
            btnSave.Visible = true;
            btnUpdate.Visible = false;
            btnDelete.Visible = false;
            rest();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtName.Text == "")
            {
                MessageBox.Show("Please enter employee name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtName.Focus();
                return;
            }
            if (txtMobileNumber.Text == "")
            {
                MessageBox.Show("Please enter mobile number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtMobileNumber.Focus();
                return;
            }
            if (txtCNICNo.Text == "")
            {
                MessageBox.Show("Please enter CNIC No", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCNICNo.Focus();
                return;
            }
            if (cmbBloodGroup.Text == "")
            {
                MessageBox.Show("Please enter blood group", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cmbBloodGroup.Focus();
                return;
            }
            if (cmbEyeColor.Text == "")
            {
                MessageBox.Show("Please enter eye color", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cmbEyeColor.Focus();
                return;
            }
            if (txtHeight.Text == "")
            {
                MessageBox.Show("Please enter height", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtHeight.Focus();
                return;
            }
            try
            {
                con = new SqlConnection(cs.DBConn);
                con.Open();
                string ct = "select MobileNumber from DonorTable where MobileNumber='" + txtMobileNumber.Text + "'";

                cmd = new SqlCommand(ct);
                cmd.Connection = con;
                rdr = cmd.ExecuteReader();

                if (rdr.Read())
                {
                    MessageBox.Show("Mobile number Already Exists", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtMobileNumber.Text = "";
                    txtMobileNumber.Focus();

                    if ((rdr != null))
                    {
                        rdr.Close();
                    }
                    return;
                }

                con = new SqlConnection(cs.DBConn);
                con.Open();
                string cb = "insert into DonorTable(DonorNo,Name,Age,Gender,MobileNumber,CNICNo,Address,BloodGroup,Height,EyeColor) VALUES ('" + txtDonorNo.Text + "','" + txtName.Text + "','" + txtAge.Text + "','" + cmbGender.Text + "','" + txtMobileNumber.Text + "','" + txtCNICNo.Text + "','" + txtAddress.Text + "','" + cmbBloodGroup.Text + "','" + txtHeight.Text + "','" + cmbEyeColor.Text + "')";
                cmd = new SqlCommand(cb);
                cmd.Connection = con;
                cmd.ExecuteReader();
                con.Close();
                MessageBox.Show("Successfully saved", "Donor Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                AutoIdGeneration();
                rest();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnViewAll_Click(object sender, EventArgs e)
        {
            ViewDonorForm VDF = new ViewDonorForm();
            VDF.Show();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtName.Text == "")
            {
                MessageBox.Show("Please enter employee name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtName.Focus();
                return;
            }
            if (txtMobileNumber.Text == "")
            {
                MessageBox.Show("Please enter mobile number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtMobileNumber.Focus();
                return;
            }
            if (txtCNICNo.Text == "")
            {
                MessageBox.Show("Please enter CNIC No", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCNICNo.Focus();
                return;
            }
            if (cmbBloodGroup.Text == "")
            {
                MessageBox.Show("Please enter blood group", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cmbBloodGroup.Focus();
                return;
            }
            if (cmbEyeColor.Text == "")
            {
                MessageBox.Show("Please enter eye color", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cmbEyeColor.Focus();
                return;
            }
            if (txtHeight.Text == "")
            {
                MessageBox.Show("Please enter height", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtHeight.Focus();
                return;
            }

            try
            {

                con = new SqlConnection(cs.DBConn);
                con.Open();
                string cb = "Update DonorTable set Name='" + txtName.Text + "',Age='" + txtAge.Text + "',Gender='" + cmbGender.Text + "',MobileNumber='" + txtMobileNumber.Text + "',CNICNo='" + txtCNICNo.Text + "',Address='" + txtAddress.Text + "',BloodGroup='" + cmbBloodGroup.Text + "',Height='" + txtHeight.Text + "',EyeColor='" + cmbEyeColor.Text + "' Where DonorNo='" + txtDonorNo.Text + "'";
                cmd = new SqlCommand(cb);
                cmd.Connection = con;
                cmd.ExecuteReader();
                con.Close();
                MessageBox.Show("Successfully updated", "Donor Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                AutoIdGeneration();
                btnSave.Visible = true;
                btnUpdate.Visible = false;
                btnDelete.Visible = false;
                rest();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show("Do you really want to delete this record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
            {
                delete_records();
            }
        }

        private void delete_records()
        {

            try
            {

                int RowsAffected = 0;
                con = new SqlConnection(cs.DBConn);
                con.Open();
                string cq = "delete from DonorTable where DonorNo='" + txtDonorNo.Text + "'";
                cmd = new SqlCommand(cq);
                cmd.Connection = con;
                RowsAffected = cmd.ExecuteNonQuery();
                if (RowsAffected > 0)
                {
                    MessageBox.Show("Successfully deleted", "Donor Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    AutoIdGeneration();
                    btnSave.Visible = true;
                    btnUpdate.Visible = false;
                    btnDelete.Visible = false;
                    rest();
                }
                else
                {
                    MessageBox.Show("No Record found", "Sorry", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    AutoIdGeneration();
                    btnSave.Visible = true;
                    btnUpdate.Visible = false;
                    btnDelete.Visible = false;
                    rest();
                }
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cmbGender_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void mobile(object sender, EventArgs e)
        {
            if (txtMobileNumber.Text.Length == 10)
            {
                label14.Text = "OK";
                label14.ForeColor = Color.Green;
            }
            else
            {
                label14.Text = "Check Number";
                label14.ForeColor = Color.Red;
            }
        }

        private void mobileno(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("enter only number");
            }
        }

        private void name(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("enter only character");
            }
        }

        private void age(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                MessageBox.Show("enter only number");
            }
        }
    }
}
