﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;
using System.IO;

namespace BloodBankManagement
{
    public partial class ReportForm : UserControl
    {
        SqlDataReader rdr = null;
        DataTable dtable = new DataTable();
        SqlConnection con = null;
        SqlCommand cmd = null;
        DataTable dt = new DataTable();
        ConnectionString cs = new ConnectionString();

        private static ReportForm _instance;

        public static ReportForm Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new ReportForm();
                return _instance;
            }
        }

        public ReportForm()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {

            this.Hide();
            FillDonor();
            FillSeeker();
        }

        public void FillDonor()
        {
            try
            {
                CmbDonor.Items.Clear();
                con = new SqlConnection(cs.DBConn);
                con.Open();
                string ct = "select RTRIM(DonorNo) from DonatedBloodTable order by DonorNo";
                cmd = new SqlCommand(ct);
                cmd.Connection = con;
                rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    CmbDonor.Items.Add(rdr[0]);
                }
                con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void FillSeeker()
        {
            try
            {
                CmbSeeker.Items.Clear();
                con = new SqlConnection(cs.DBConn);
                con.Open();
                string ct = "Select RTRIM(PatientNo) from SeekerBloodTable order by PatientNo";
                cmd = new SqlCommand(ct);
                cmd.Connection = con;
                rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    CmbSeeker.Items.Add(rdr[0]);
                }
                con.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CmbSeeker_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con = new SqlConnection(cs.DBConn);
                con.Open();
                cmd = new SqlCommand("SELECT * from SeekerBloodTable where PatientNo ='" + CmbSeeker.Text + "' order by ID", con);
                SqlDataAdapter myDA = new SqlDataAdapter(cmd);
                DataSet myDataSet = new DataSet();
                myDA.Fill(myDataSet, "SeekerBloodTable");
                dataGridView2.DataSource = myDataSet.Tables["SeekerBloodTable"].DefaultView;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CmbDonor_SelectedIndexChanged(object sender, EventArgs e)
        {

            try
            {
                con = new SqlConnection(cs.DBConn);
                con.Open();
                cmd = new SqlCommand("SELECT * from DonatedBloodTable where DonorNo ='" + CmbDonor.Text + "' order by ID", con);
                SqlDataAdapter myDA = new SqlDataAdapter(cmd);
                DataSet myDataSet = new DataSet();
                myDA.Fill(myDataSet, "DonatedBloodTable");
                dataGridView1.DataSource = myDataSet.Tables["DonatedBloodTable"].DefaultView;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ReportForm_Load(object sender, EventArgs e)
        {
            FillDonor();
            FillSeeker();
        }

    }
}
