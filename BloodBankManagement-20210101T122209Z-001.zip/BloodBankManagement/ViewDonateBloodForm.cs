﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;

namespace BloodBankManagement
{
    public partial class ViewDonateBloodForm : Form
    {
        SqlDataReader rdr = null;
        DataTable dtable = new DataTable();
        SqlConnection con = null;
        SqlCommand cmd = null;
        DataTable dt = new DataTable();
        ConnectionString cs = new ConnectionString();

        public ViewDonateBloodForm()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Hide();
            dataGridView1.DataSource = GetData();
        }

        private void ViewDonateBloodForm_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = GetData();
        }

        private SqlConnection Connection
        {
            get
            {
                SqlConnection ConnectionToFetch = new SqlConnection(cs.DBConn);
                ConnectionToFetch.Open();
                return ConnectionToFetch;
            }
        }

        public DataView GetData()
        {
            var SelectQry = "select Id,DonorNo,Name,DateOfDonation,DonatedBloodBefore,BloodGroup from DonatedBloodTable ORDER BY Id asc";

            DataSet SampleSource = new DataSet();
            DataView TableView;
            try
            {
                SqlCommand SampleCommand = new SqlCommand();
                var SampleDataAdapter = new SqlDataAdapter();
                SampleCommand.CommandText = SelectQry;
                SampleCommand.Connection = Connection;
                SampleDataAdapter.SelectCommand = SampleCommand;
                SampleDataAdapter.Fill(SampleSource);
                TableView = SampleSource.Tables[0].DefaultView;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return TableView;
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                con = new SqlConnection(cs.DBConn);
                con.Open();
                cmd = new SqlCommand("select Id, DonorNo,Name,DateOfDonation,DonatedBloodBefore,BloodGroup from DonatedBloodTable where DonorNo like '%" + txtSearch.Text + "%' or Name like '%" + txtSearch.Text + "%' or BloodGroup like '%" + txtSearch.Text + "%' order by Id", con);
                SqlDataAdapter myDA = new SqlDataAdapter(cmd);
                DataSet myDataSet = new DataSet();
                myDA.Fill(myDataSet, "DonatedBloodTable");
                dataGridView1.DataSource = myDataSet.Tables["DonatedBloodTable"].DefaultView;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                DataGridViewRow dr = dataGridView1.SelectedRows[0];
                DonateBloodForm.Instance.lblId.Text = dr.Cells[0].Value.ToString();
                DonateBloodForm.Instance.cmbDonorNo.Text = dr.Cells[1].Value.ToString();
                DonateBloodForm.Instance.txtName.Text = dr.Cells[2].Value.ToString();
                DonateBloodForm.Instance.dtpDateOfDonation.Text = dr.Cells[3].Value.ToString();
                DonateBloodForm.Instance.cmbDontaedBloodBefore.Text = dr.Cells[4].Value.ToString();
                DonateBloodForm.Instance.txtBloodGroup.Text = dr.Cells[5].Value.ToString();
                DonateBloodForm.Instance.btnUpdate.Visible = true;
                DonateBloodForm.Instance.btnDelete.Visible = true;
                DonateBloodForm.Instance.btnSave.Visible = false;
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
