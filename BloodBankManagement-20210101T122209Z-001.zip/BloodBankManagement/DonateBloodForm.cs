﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;

namespace BloodBankManagement
{
    public partial class DonateBloodForm : UserControl
    {
        SqlDataReader rdr = null;
        DataTable dtable = new DataTable();
        SqlConnection con = null;
        SqlCommand cmd = null;
        DataTable dt = new DataTable();
        ConnectionString cs = new ConnectionString();

        private static DonateBloodForm _instance;

        public static DonateBloodForm Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new DonateBloodForm();
                return _instance;
            }
        }


        public DonateBloodForm()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Hide();
            rest();
            btnUpdate.Visible = false;
            btnDelete.Visible = false;
            btnSave.Visible = true;
            FillData();
        }

        private void rest()
        {
            txtName.Text = "";
            txtBloodGroup.Text = "";
            cmbDontaedBloodBefore.Text = "";
            cmbDonorNo.Text = "";
            dtpDateOfDonation.Text = DateTime.Today.ToString();
        }

        public void FillData()
        {
            try
            {
                cmbDonorNo.Items.Clear();
                con = new SqlConnection(cs.DBConn);
                con.Open();
                string ct = "select RTRIM(DonorNo) from DonorTable order by DonorNo";
                cmd = new SqlCommand(ct);
                cmd.Connection = con;
                rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    cmbDonorNo.Items.Add(rdr[0]);
                }
                con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DonateBloodForm_Load(object sender, EventArgs e)
        {
            btnSave.Visible = true;
            btnUpdate.Visible = false;
            btnDelete.Visible = false;
            rest();
            FillData();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtName.Text == "")
            {
                MessageBox.Show("Please enter employee name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtName.Focus();
                return;
            }
            if (cmbDonorNo.Text == "")
            {
                MessageBox.Show("Please select donor number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cmbDonorNo.Focus();
                return;
            }
            if (cmbDontaedBloodBefore.Text == "")
            {
                MessageBox.Show("Please select donated blood before", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cmbDontaedBloodBefore.Focus();
                return;
            }
            try
            {
                con = new SqlConnection(cs.DBConn);
                con.Open();
                string cb = "insert into DonatedBloodTable(DonorNo,Name,DateOfDonation,DonatedBloodBefore,BloodGroup) VALUES ('" + cmbDonorNo.Text + "','" + txtName.Text + "','" + dtpDateOfDonation.Text + "','" + cmbDontaedBloodBefore.Text + "','" + txtBloodGroup.Text + "')";
                cmd = new SqlCommand(cb);
                cmd.Connection = con;
                cmd.ExecuteReader();
                con.Close();

                con = new SqlConnection(cs.DBConn);
                con.Open();

                string cb3 = "update BloodStockTable set Quantity = Quantity + 1  where BloodGroup ='" + txtBloodGroup.Text + "'";

                cmd = new SqlCommand(cb3);

                cmd.Connection = con;

                cmd.ExecuteReader();
                con.Close();

                MessageBox.Show("Successfully saved", "Donated Blood Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                rest();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cmbDonorNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con = new SqlConnection(cs.DBConn);
                con.Open();
                cmd = con.CreateCommand();

                cmd.CommandText = "SELECT Name,BloodGroup from DonorTable WHERE DonorNo = '" + cmbDonorNo.Text + "'";
                rdr = cmd.ExecuteReader();

                if (rdr.Read())
                {
                    txtName.Text = rdr.GetValue(0).ToString().Trim();
                    txtBloodGroup.Text = rdr.GetValue(1).ToString().Trim();
                }
                if ((rdr != null))
                {
                    rdr.Close();
                }
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnViewAll_Click(object sender, EventArgs e)
        {
            ViewDonateBloodForm VDBF = new ViewDonateBloodForm();
            VDBF.Show();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            if (txtName.Text == "")
            {
                MessageBox.Show("Please enter employee name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtName.Focus();
                return;
            }
            if (cmbDonorNo.Text == "")
            {
                MessageBox.Show("Please select donor number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cmbDonorNo.Focus();
                return;
            }
            if (cmbDontaedBloodBefore.Text == "")
            {
                MessageBox.Show("Please select donated blood before", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cmbDontaedBloodBefore.Focus();
                return;
            }
            try
            {
                con = new SqlConnection(cs.DBConn);
                con.Open();
                string cb = "Update DonatedBloodTable set DonorNo='" + cmbDonorNo.Text + "',Name='" + txtName.Text + "',DateOfDonation='" + dtpDateOfDonation.Text + "',DonatedBloodBefore='" + cmbDontaedBloodBefore.Text + "',BloodGroup='" + txtBloodGroup.Text + "' Where Id='" + lblId.Text + "'";
                cmd = new SqlCommand(cb);
                cmd.Connection = con;
                cmd.ExecuteReader();
                con.Close();
                MessageBox.Show("Successfully updated", "Donated Blood Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                btnSave.Visible = true;
                btnUpdate.Visible = false;
                btnDelete.Visible = false;
                rest();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you really want to delete this record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
            {
                delete_records();
            }
        }

        private void delete_records()
        {

            try
            {

                int RowsAffected = 0;
                con = new SqlConnection(cs.DBConn);
                con.Open();
                string cq = "delete from DonatedBloodTable where Id='" + lblId.Text + "'";
                cmd = new SqlCommand(cq);
                cmd.Connection = con;
                RowsAffected = cmd.ExecuteNonQuery();
                if (RowsAffected > 0)
                {
                    con = new SqlConnection(cs.DBConn);
                    con.Open();
                    string cb3 = "update BloodStockTable set Quantity = Quantity - 1  where BloodGroup ='" + txtBloodGroup.Text + "'";
                    cmd = new SqlCommand(cb3);
                    cmd.Connection = con;
                    cmd.ExecuteReader();
                    con.Close();

                    MessageBox.Show("Successfully deleted", "Donated Blood Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btnSave.Visible = true;
                    btnUpdate.Visible = false;
                    btnDelete.Visible = false;
                    rest();
                }
                else
                {
                    MessageBox.Show("No Record found", "Sorry", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btnSave.Visible = true;
                    btnUpdate.Visible = false;
                    btnDelete.Visible = false;
                    rest();
                }
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}


