﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;

namespace BloodBankManagement
{
    public partial class ViewEmployeeForm : Form
    {
        SqlDataReader rdr = null;
        DataTable dtable = new DataTable();
        SqlConnection con = null;
        SqlCommand cmd = null;
        DataTable dt = new DataTable();
        ConnectionString cs = new ConnectionString();

        public ViewEmployeeForm()
        {
            InitializeComponent();
        }

        private void ViewEmployeeForm_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = GetData();
        }

        private SqlConnection Connection
        {
            get
            {
                SqlConnection ConnectionToFetch = new SqlConnection(cs.DBConn);
                ConnectionToFetch.Open();
                return ConnectionToFetch;
            }
        }

        public DataView GetData()
        {
            var SelectQry = "select EmployeeNo,Name,MobileNumber,MailId,Gender,DateOfBirth,Address from EmployeeTable ORDER BY Id asc";

            DataSet SampleSource = new DataSet();
            DataView TableView;
            try
            {
                SqlCommand SampleCommand = new SqlCommand();
                var SampleDataAdapter = new SqlDataAdapter();
                SampleCommand.CommandText = SelectQry;
                SampleCommand.Connection = Connection;
                SampleDataAdapter.SelectCommand = SampleCommand;
                SampleDataAdapter.Fill(SampleSource);
                TableView = SampleSource.Tables[0].DefaultView;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return TableView;
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                DataGridViewRow dr = dataGridView1.SelectedRows[0];
                EmployeeForm.Instance.txtEmployeeNo.Text = dr.Cells[0].Value.ToString();
                EmployeeForm.Instance.txtName.Text = dr.Cells[1].Value.ToString();
                EmployeeForm.Instance.txtMobileNumber.Text = dr.Cells[2].Value.ToString();
                EmployeeForm.Instance.txtMailId.Text = dr.Cells[3].Value.ToString();
                EmployeeForm.Instance.cmbGender.Text = dr.Cells[4].Value.ToString();
                EmployeeForm.Instance.dtpDateOfBirth.Text = dr.Cells[5].Value.ToString();
                EmployeeForm.Instance.txtAddress.Text = dr.Cells[6].Value.ToString();
                EmployeeForm.Instance.btnUpdate.Visible = true;
                EmployeeForm.Instance.btnDelete.Visible = true;
                EmployeeForm.Instance.btnSave.Visible = false;
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Hide();
            dataGridView1.DataSource = GetData();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                con = new SqlConnection(cs.DBConn);
                con.Open();
                cmd = new SqlCommand("select EmployeeNo,Name,MobileNumber,MailId,Gender,DateOfBirth,Address from EmployeeTable where EmployeeNo like '%" + txtSearch.Text + "%' or Name like '%" + txtSearch.Text + "%' or MobileNumber like '%" + txtSearch.Text + "%' or MailId like '%" + txtSearch.Text + "%'  order by Id", con);
                SqlDataAdapter myDA = new SqlDataAdapter(cmd);
                DataSet myDataSet = new DataSet();
                myDA.Fill(myDataSet, "EmployeeTable");
                dataGridView1.DataSource = myDataSet.Tables["EmployeeTable"].DefaultView;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
