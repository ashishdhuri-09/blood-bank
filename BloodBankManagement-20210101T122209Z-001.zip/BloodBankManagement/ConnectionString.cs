﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BloodBankManagement
{
    class ConnectionString
    {
        public string DBConn = "Data Source=USER-PC;Initial Catalog=BloodBankManagement;Integrated Security=True";
    }
}
