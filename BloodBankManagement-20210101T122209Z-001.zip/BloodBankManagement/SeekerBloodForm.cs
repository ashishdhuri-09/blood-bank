﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;

namespace BloodBankManagement
{
    public partial class SeekerBloodForm : UserControl
    {
        SqlDataReader rdr = null;
        DataTable dtable = new DataTable();
        SqlConnection con = null;
        SqlCommand cmd = null;
        DataTable dt = new DataTable();
        ConnectionString cs = new ConnectionString();

        private static SeekerBloodForm _instance;

        public static SeekerBloodForm Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new SeekerBloodForm();
                return _instance;
            }
        }

        public SeekerBloodForm()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Hide();
            FillData();
            btnTransfer.Visible = false;
        }

        public void FillData()
        {
            try
            {
                cmbPatientNo.Items.Clear();
                con = new SqlConnection(cs.DBConn);
                con.Open();
                string ct = "select RTRIM(PatientNo) from SeekerTable order by PatientNo";
                cmd = new SqlCommand(ct);
                cmd.Connection = con;
                rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    cmbPatientNo.Items.Add(rdr[0]);
                }
                con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SeekerBloodForm_Load(object sender, EventArgs e)
        {
            FillData();
            btnTransfer.Visible = false;
        }

        private void cmbPatientNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con = new SqlConnection(cs.DBConn);
                con.Open();
                cmd = con.CreateCommand();

                cmd.CommandText = "SELECT Name,BloodGroup from SeekerTable WHERE PatientNo = '" + cmbPatientNo.Text + "'";
                rdr = cmd.ExecuteReader();

                if (rdr.Read())
                {
                    txtName.Text = rdr.GetValue(0).ToString().Trim();
                    txtBloodGroup.Text = rdr.GetValue(1).ToString().Trim();
                }
                if ((rdr != null))
                {
                    rdr.Close();
                }
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAvailable_Click(object sender, EventArgs e)
        {
            try
            {
                con = new SqlConnection(cs.DBConn);
                con.Open();
                string ct = "select BloodGroup from BloodStockTable where BloodGroup='" + txtBloodGroup.Text + "' And Quantity !='0'";
                cmd = new SqlCommand(ct);
                cmd.Connection = con;
                rdr = cmd.ExecuteReader();
                if (rdr.Read())
                {
                    MessageBox.Show("Blood Group Available In Bank", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btnTransfer.Visible = true;
                    btnAvailable.Visible = false;
                }
                else
                {
                    MessageBox.Show("Blood Group Not Available In Bank", "Info", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    btnTransfer.Visible = false;
                    btnAvailable.Visible = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnTransfer_Click(object sender, EventArgs e)
        {
            try
            {
                con = new SqlConnection(cs.DBConn);
                con.Open();
                string cb = "insert into SeekerBloodTable(PatientNo,Name,BloodGroup,Status) VALUES ('" + cmbPatientNo.Text + "','" + txtName.Text + "','" + txtBloodGroup.Text + "','Received')";
                cmd = new SqlCommand(cb);
                cmd.Connection = con;
                cmd.ExecuteReader();
                con.Close();

                con = new SqlConnection(cs.DBConn);
                con.Open();

                string cb3 = "update BloodStockTable set Quantity = Quantity - 1  where BloodGroup ='" + txtBloodGroup.Text + "'";

                cmd = new SqlCommand(cb3);

                cmd.Connection = con;

                cmd.ExecuteReader();
                con.Close();

                MessageBox.Show("Successfully saved", "Seeker Blood Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cmbPatientNo.Text = "";
                txtBloodGroup.Text = "";
                txtName.Text = "";
                btnTransfer.Visible = false;
                btnAvailable.Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
