﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BloodBankManagement
{
    public partial class HomForm : Form
    {
        public HomForm()
        {
            InitializeComponent();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm LF = new LoginForm();
            LF.Show();
        }

        private void btnDonor_Click(object sender, EventArgs e)
        {
            SidePanel.Left = btnDonor.Left;
            if (!HomePanel.Controls.Contains(DonorForm.Instance))
            {
                HomePanel.Controls.Add(DonorForm.Instance);
                DonorForm.Instance.Dock = DockStyle.Fill;
                DonorForm.Instance.BringToFront();
                DonorForm.Instance.Visible = true;
            }
            else
                DonorForm.Instance.BringToFront();
            DonorForm.Instance.Visible = true;
        }

        private void btnSeeker_Click(object sender, EventArgs e)
        {
            SidePanel.Left = btnSeeker.Left;
            if (!HomePanel.Controls.Contains(SeekerForm.Instance))
            {
                HomePanel.Controls.Add(SeekerForm.Instance);
                SeekerForm.Instance.Dock = DockStyle.Fill;
                SeekerForm.Instance.BringToFront();
                SeekerForm.Instance.Visible = true;
            }
            else
                SeekerForm.Instance.BringToFront();
            SeekerForm.Instance.Visible = true;
        }

        private void btnDonateBlood_Click(object sender, EventArgs e)
        {
            SidePanel.Left = btnDonateBlood.Left;
            if (!HomePanel.Controls.Contains(DonateBloodForm.Instance))
            {
                HomePanel.Controls.Add(DonateBloodForm.Instance);
                DonateBloodForm.Instance.Dock = DockStyle.Fill;
                DonateBloodForm.Instance.BringToFront();
                DonateBloodForm.Instance.Visible = true;
            }
            else
                DonateBloodForm.Instance.BringToFront();
            DonateBloodForm.Instance.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SidePanel.Left = button1.Left;
            if (!HomePanel.Controls.Contains(SeekerBloodForm.Instance))
            {
                HomePanel.Controls.Add(SeekerBloodForm.Instance);
                SeekerBloodForm.Instance.Dock = DockStyle.Fill;
                SeekerBloodForm.Instance.BringToFront();
                SeekerBloodForm.Instance.Visible = true;
            }
            else
                SeekerBloodForm.Instance.BringToFront();
            SeekerBloodForm.Instance.Visible = true;
        }

        private void btnBloodStock_Click(object sender, EventArgs e)
        {
            SidePanel.Left = btnBloodStock.Left;
            if (!HomePanel.Controls.Contains(BloodStockForm.Instance))
            {
                HomePanel.Controls.Add(BloodStockForm.Instance);
                BloodStockForm.Instance.Dock = DockStyle.Fill;
                BloodStockForm.Instance.BringToFront();
                BloodStockForm.Instance.Visible = true;
            }
            else
                BloodStockForm.Instance.BringToFront();
            BloodStockForm.Instance.Visible = true;
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            SidePanel.Left = btnReport.Left;
            if (!HomePanel.Controls.Contains(ReportForm.Instance))
            {
                HomePanel.Controls.Add(ReportForm.Instance);
                ReportForm.Instance.Dock = DockStyle.Fill;
                ReportForm.Instance.BringToFront();
                ReportForm.Instance.Visible = true;
            }
            else
                ReportForm.Instance.BringToFront();
            ReportForm.Instance.Visible = true;
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            SidePanel.Left = btnSettings.Left;
            contextMenuStrip1.Show(btnSettings, 0, btnSettings.Height);
        }

        private void userToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!HomePanel.Controls.Contains(UserForm.Instance))
            {
                HomePanel.Controls.Add(UserForm.Instance);
                UserForm.Instance.Dock = DockStyle.Fill;
                UserForm.Instance.BringToFront();
                UserForm.Instance.Visible = true;
            }
            else
                UserForm.Instance.BringToFront();
            UserForm.Instance.Visible = true;
        }

       

        private void employeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!HomePanel.Controls.Contains(EmployeeForm.Instance))
            {
                HomePanel.Controls.Add(EmployeeForm.Instance);
                EmployeeForm.Instance.Dock = DockStyle.Fill;
                EmployeeForm.Instance.BringToFront();
                EmployeeForm.Instance.Visible = true;
            }
            else
                EmployeeForm.Instance.BringToFront();
            EmployeeForm.Instance.Visible = true;
        }


    }
}
