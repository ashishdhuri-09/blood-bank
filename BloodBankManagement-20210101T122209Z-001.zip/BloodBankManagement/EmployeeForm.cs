﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;

namespace BloodBankManagement
{
    public partial class EmployeeForm : UserControl
    {
        SqlDataReader rdr = null;
        DataTable dtable = new DataTable();
        SqlConnection con = null;
        SqlCommand cmd = null;
        DataTable dt = new DataTable();
        ConnectionString cs = new ConnectionString();

        private static EmployeeForm _instance;

        public static EmployeeForm Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new EmployeeForm();
                return _instance;
            }
        }

        public EmployeeForm()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Hide();
            rest();
            btnUpdate.Visible = false;
            btnDelete.Visible = false;
            btnSave.Visible = true;
        }

        private void AutoIdGeneration()
        {
            int Num = 0;
            con = new SqlConnection(cs.DBConn);
            con.Open();
            string sql = "SELECT Max(Id+1) FROM EmployeeTable";
            cmd = new SqlCommand(sql);
            cmd.Connection = con;
            if (Convert.IsDBNull(cmd.ExecuteScalar()))
            {
                Num = 1;
                lblEmployeeNo.Text = Convert.ToString(Num);
                txtEmployeeNo.Text = Convert.ToString("EMP-" + Num);
            }
            else
            {
                Num = System.Convert.ToInt32((cmd.ExecuteScalar()));
                lblEmployeeNo.Text = Convert.ToString(Num);
                txtEmployeeNo.Text = Convert.ToString("EMP-" + Num);
            }
            cmd.Dispose();
            con.Close();
            con.Dispose();
        }

        private void rest()
        {
            txtName.Text = "";
            txtAddress.Text = "";
            txtMobileNumber.Text = "";
            txtMailId.Text = "";
            cmbGender.Text = "";
            dtpDateOfBirth.Text = DateTime.Today.ToString();
        }

        private void EmployeeForm_Load(object sender, EventArgs e)
        {
            AutoIdGeneration();
            btnSave.Visible = true;
            btnUpdate.Visible = false;
            btnDelete.Visible = false;
            rest();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtName.Text == "")
            {
                MessageBox.Show("Please enter employee name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtName.Focus();
                return;
            }
            if (txtMobileNumber.Text == "")
            {
                MessageBox.Show("Please enter mobile number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtMobileNumber.Focus();
                return;
            }
            if (txtMailId.Text == "")
            {
                MessageBox.Show("Please enter mail id", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtMailId.Focus();
                return;
            }
            try
            {
                con = new SqlConnection(cs.DBConn);
                con.Open();
                string ct = "select MobileNumber from EmployeeTable where MobileNumber='" + txtMobileNumber.Text + "'";

                cmd = new SqlCommand(ct);
                cmd.Connection = con;
                rdr = cmd.ExecuteReader();

                if (rdr.Read())
                {
                    MessageBox.Show("Mobile number Already Exists", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtMobileNumber.Text = "";
                    txtMobileNumber.Focus();

                    if ((rdr != null))
                    {
                        rdr.Close();
                    }
                    return;
                }

                con = new SqlConnection(cs.DBConn);
                con.Open();
                string cb = "insert into EmployeeTable(EmployeeNo,Name,MobileNumber,MailId,Gender,DateOfBirth,Address) VALUES ('" + txtEmployeeNo.Text + "','" + txtName.Text + "','" + txtMobileNumber.Text + "','" + txtMailId.Text + "','" + cmbGender.Text + "','" + dtpDateOfBirth.Text + "','" + txtAddress.Text + "')";
                cmd = new SqlCommand(cb);
                cmd.Connection = con;
                cmd.ExecuteReader();
                con.Close();
                MessageBox.Show("Successfully saved", "Employee Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                AutoIdGeneration();
                rest();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnViewAll_Click(object sender, EventArgs e)
        {
            ViewEmployeeForm VEF = new ViewEmployeeForm();
            VEF.ShowDialog();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtName.Text == "")
            {
                MessageBox.Show("Please enter employee name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtName.Focus();
                return;
            }
            if (txtMobileNumber.Text == "")
            {
                MessageBox.Show("Please enter mobile number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtMobileNumber.Focus();
                return;
            }
            if (txtMailId.Text == "")
            {
                MessageBox.Show("Please enter mail id", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtMailId.Focus();
                return;
            }
            try
            {

                con = new SqlConnection(cs.DBConn);
                con.Open();
                string cb = "Update EmployeeTable set Name='" + txtName.Text + "',Address='" + txtAddress.Text + "',MobileNumber='" + txtMobileNumber.Text + "',MailId='" + txtMailId.Text + "',Gender='" + cmbGender.Text + "',DateOfBirth='" + dtpDateOfBirth.Text + "' Where EmployeeNo='" + txtEmployeeNo.Text + "'";
                cmd = new SqlCommand(cb);
                cmd.Connection = con;
                cmd.ExecuteReader();
                con.Close();
                MessageBox.Show("Successfully updated", "Employee Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                AutoIdGeneration();
                btnSave.Visible = true;
                btnUpdate.Visible = false;
                btnDelete.Visible = false;
                rest();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you really want to delete this record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
            {
                delete_records();
            }
        }

        private void delete_records()
        {

            try
            {

                int RowsAffected = 0;
                con = new SqlConnection(cs.DBConn);
                con.Open();
                string cq = "delete from EmployeeTable where EmployeeNo='" + txtEmployeeNo.Text + "'";
                cmd = new SqlCommand(cq);
                cmd.Connection = con;
                RowsAffected = cmd.ExecuteNonQuery();
                if (RowsAffected > 0)
                {
                    MessageBox.Show("Successfully deleted", "Employee Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    AutoIdGeneration();
                    btnSave.Visible = true;
                    btnUpdate.Visible = false;
                    btnDelete.Visible = false;
                    rest();
                }
                else
                {
                    MessageBox.Show("No Record found", "Sorry", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    AutoIdGeneration();
                    btnSave.Visible = true;
                    btnUpdate.Visible = false;
                    btnDelete.Visible = false;
                    rest();
                }
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

    }
}
