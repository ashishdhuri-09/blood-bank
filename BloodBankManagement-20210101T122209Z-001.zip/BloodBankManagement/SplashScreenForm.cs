﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BloodBankManagement
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                rectangleShape1.Width += 1;
                if (rectangleShape1.Width >= 525)
                {
                    timer1.Stop();
                    LoginForm L1 = new LoginForm();
                    this.Hide();
                    L1.ShowDialog();
                }

            }
            catch (Exception)
            {
                return;
            }
        }
    }
}
